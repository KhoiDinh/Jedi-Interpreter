package expression
import context._

case class Block (expression: List[Expression]) extends SpecialForm
{
  def execute(env: Environment)=
  {
    var tempEnv = new Environment(env)
    var executed = expression.map(_.execute(tempEnv))
    executed.last
  }
}