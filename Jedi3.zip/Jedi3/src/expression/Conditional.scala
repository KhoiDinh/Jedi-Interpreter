package expression
import context._
import value._

case class Conditional(val conditional: Expression, val consequent: Expression, val alternative: Expression = null) extends SpecialForm
{
  def execute(env: Environment) =
  {
     val cond = conditional.execute(env)
     
     if(cond.isInstanceOf[Boole])
     {
       if(cond.asInstanceOf[value.Boole].value)
       {
         consequent.execute(env)
       }
       else if(alternative != null)
       {
         alternative.execute(env)
       }
       else
       {
         Notification.UNSPECIFIED
       }
     }
     else
     {
       throw new TypeException("Conditional requires a Boole arguement")
     }
  }
}