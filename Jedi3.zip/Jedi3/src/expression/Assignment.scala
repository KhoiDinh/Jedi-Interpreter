package expression

import context._
import value._


case class Assignment(vbl: Identifier, update:Expression) extends SpecialForm 
{
  def execute(env: Environment)=
  {
    var hold = vbl.execute(env)
    if(!hold.isInstanceOf[Variable])
    {
      throw new TypeException("Only Variable objects can be modified")
    }
    
    hold.asInstanceOf[Variable].content = update.execute(env)
    Notification.DONE
  }
}