package expression
import context._
import value._

case class Identifier(val name: String) extends Expression{ 
  override def toString = name
  /*def execute(env: Environment): Value = {
    env(this)
    
  }*/
  
  def execute(env:Environment): Value = 
  {
    
    if(env(this).isInstanceOf[Text])
    {
      env(this).asInstanceOf[Text].body.execute(env)
    }
    else if(env(this).isInstanceOf[Thunk])
    {
      env(this).asInstanceOf[Thunk].apply()
    }
    else
    {
      env.apply(this)
    }
  }
}