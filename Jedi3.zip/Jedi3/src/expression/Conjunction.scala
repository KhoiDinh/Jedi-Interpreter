package expression
import context._ 
import value._

//INCORRECT
case class Conjunction(list: List[Expression]) extends SpecialForm 
{
  def execute(env: Environment): Value= 
  {
    var result = true
    
    for(exp <- list; if(result))
    {
      var singleResult = exp.execute(env)
      if(singleResult.isInstanceOf[Boole])
      {
        result = singleResult.asInstanceOf[Boole].value
      }
      else
      {
        throw new TypeException("conjunction function only accepts Boole arguements")
      }
    }
    new Boole(result)
  }
}