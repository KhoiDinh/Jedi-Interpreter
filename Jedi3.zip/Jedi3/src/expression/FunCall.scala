package expression
import context.Environment
import value._
import context._

case class FunCall(val operator: Identifier, val operands: List[Expression]) extends Expression {
  /*def execute(env: Environment) =
    {
      var eager = operands.map(_.execute(env))

      try
      {
        var test = operator.execute(env)
        if(test.isInstanceOf[Closure])
        {
          var confirmed = test.asInstanceOf[Closure]
          confirmed.apply(eager) //env for jedi 2.1
        }
        else
        {
          throw new TypeException("only function can be called")
        }
      }
      catch
      {
        case e: UndefinedException => alu2.execute(operator,eager)
      }
    }*/

  //define function = freeze
  //consolt flag - valueExecute text- create text, name-func
  //know whne inside of closure, create bindings
  //ident execute-> give an identifier- searches evironement and get value (text-> execute body of text in current env, closure-> apply closure, none - return value)

  //jedi 2.1 version
  def execute(env: Environment) =
    {
  /*    try {
      //if(env.contains(operator)){do what you are doing rn} else {...}
        var test = operator.execute(env)
        if (test.isInstanceOf[Closure]) {
          var arguments =
            {
              Flags.paramaterPassing match {
                case Flags.passByValue => operands.map(_.execute(env))
                case Flags.passByText  => operands.map(new Text(_))
                case Flags.passByName  => operands.map(new Thunk(env, _))
              }
            }
          test.asInstanceOf[Closure].apply(arguments, env)

        } else {
          throw new TypeException("Element not closure")
        }

      } catch {
        case e: UndefinedException => alu2.execute(operator, operands.map(_.execute(env)))
      }*/
    
    //if(env.contains(operator)){do what you are doing rn} else {...}
        if(env.contains(operator))
        {
          var test = operator.execute(env)
            if (test.isInstanceOf[Closure]) {
          var arguments =
            {
              Flags.paramaterPassing match {
                case Flags.passByValue => operands.map(_.execute(env))
                case Flags.passByText  => operands.map(new Text(_))
                case Flags.passByName  => operands.map(new Thunk(env, _))
              }
            }
          test.asInstanceOf[Closure].apply(arguments, env)

        } else {
          throw new TypeException("Element not closure")
        }
        }
        else
        {
          alu2.execute(operator, operands.map(_.execute(env)))
        }

    }

}