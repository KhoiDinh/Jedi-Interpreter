package expression
import context._
import value._

case class Disjunction(list: List[Expression]) extends SpecialForm  
{
  def execute(env: Environment): Value= 
  {
    var result = false
    
    for(exp <- list; if(!result))
    {
      var singleResult = exp.execute(env)
      if(singleResult.isInstanceOf[Boole])
      {
        result = singleResult.asInstanceOf[Boole].value
      }
      else
      {
        throw new TypeException("disjunction function only accepts Boole arguements")
      }
      
    }
    new Boole(result)
  }
}