package test

import value._
//import value.Real.realToInt
//import value.Integer.intToReal

object NumberTest1 extends App {
  var i1 = Integer(7)
  var i2 = Integer(6)
  
  var i3 = Integer(2)
  var i4 = Integer(3)
  var i5 = Integer(5)
  
  println(i1 + i2)
  println("i1 * i2 = " + (i1 * i2))
  println("i1 == i2 = " + (i1 == i2)) //RIGHT ==, CHECKED WITH PRINT STATEMENT IN EQUAL
  println("i1 < i2 = " + (i1 < i2))  // USE COMPARE FROM CLASS, CORRECT CAUSED CHECKED WITH PRINT STATEMENT
  println("i1.## = " + i1.##)
  println("test= " + (i3+i4*i5))
  println(i1 != i2)
  
  
  var r1 = Real(3.14)
  var r2 = Real(2.71)
  var r3 = Real(0.0)
  var r4 = Real(-1.0)
  println("r1 * r2 = " + (r1 * r2))
  println("r1 == r2 = " + (r1 == r2)) //correct
  println("r1 < r2 = " + (r1 < r2)) //correct
  println("r1.## = " + r1.##)
  println(r1 != r2)
  
  println("r1 * i2 = " + (r1 * i2))
  println("i1 * r2 = " + (i1 * r2))
  
  var z0 = Integer(0)
  var zB = Boole(false)
  
  println("Boole == Integer : " + (z0 == zB))
  
  
  try
  {
    println(i1 /z0)
  }
  catch
  {
    case e: Exception => println(e)
  }
  
  println(-i1)
       try
  {
    println(r1 /r3)
  }
  catch
  {
    case e: Exception => println(e)
  }
  println(-r1)
  println(-i1)
  println(r1/r4)
  
  println(r1 == Real(3.14))
  println(i1 == Integer(7))
  println(Real(7) == i1)
  println(i1 == Real(7))
  
  println(Real(7) + i1)
  println(Real(3.14)/ Integer(2))
  println(Real(3.14) * Integer(2))
  println(Integer(2) * Real(3.14))
  println(Integer(2) < Real(3.14))
  println(Real(3.14) < Integer(2))
  println(Real(3.14) != Integer(2))

  println(Integer(3)/Real(1.5)) //3
  
  /*println(Chars("i") + " " + Integer(3))
  println(Integer(3) + " " + Chars("i"))
  println(Chars("i") + " " + Real(3))
  println(Real(3) + " " + Chars("i"))
  println(Boole(true) + " " + Integer(3))
  println(Integer(3) + " " + Boole(true))
  println(Boole(true) + " " + Real(3))
  println(Real(3) + " " + Boole(true))
  println(Boole(true) + " " + Chars("hi"))
  println(Chars("hi") + " " + Boole(true))*/
  
  //NEED BOOLE TO CHARS, CHARS TO BOOLE, INT TO CHARS, CHARS TO INT, CHAR TO REAL, REAL TO CHARS CONVERSIONS?????????

}