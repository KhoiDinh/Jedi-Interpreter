package value
import expression.Literal

case class Real(val value: Double) extends Literal with Ordered[Real] with Equals {
  def +(other: Real) = Real(this.value + other.value)
  def -(other: Real) = Real(this.value - other.value)
  def *(other: Real) = Real(this.value * other.value)
  def /(other: Real) = if (other.value != 0) Real(this.value / other.value) else throw new Exception("Can't divide by 0")
  def unary_-() = Real(-this.value)
  // etc.

  override def toString = value.toString
  def compare(other: Real): Int = if (this.value < other.value) -1 else if (other.value < this.value) 1 else 0
  override def canEqual(other: Any) = other.isInstanceOf[Real]
  override def equals(other: Any): Boolean =
    other match {
      case other: Real => this.canEqual(other) && (other.value == this.value)
      case other2: Integer => (other2.value == this.value) //NEEDED?
      case _           =>         false
    }

  override def hashCode = this.toString.##
}

object Real {
  //implicit def realToInt(n: Real): Integer = Integer(n.value.toInt)
  
}