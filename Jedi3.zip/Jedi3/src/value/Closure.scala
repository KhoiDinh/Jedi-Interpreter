package value
import context._
import expression._
class Closure(defEnv: Environment, body: Expression, parameter: List[Identifier]) extends Value {
  /*def apply(args: List[Value])= //env2 is for jedi 2.1
  {
    if(parameter.length != args.length)
    {
      throw new TypeException("paramter and arguement size should be the same")
    }

    var tempEnv = new Environment(defEnv)
    tempEnv.bulkPut(parameter, args)
    body.execute(tempEnv)
  }*/

  def apply(args: List[Value], env2: Environment) = //env2 is for jedi 2.1, was env2=null
    {
      if (parameter.length != args.length) {
        throw new TypeException("paramter and arguement size should be the same")
      }

      var tempEnv =
        {
          if (Flags.useStaticScopeRule) {
            new Environment(defEnv)

          } else {
            new Environment(env2)
          }
        }
      tempEnv.bulkPut(parameter, args)
      body.execute(tempEnv)
    }

}