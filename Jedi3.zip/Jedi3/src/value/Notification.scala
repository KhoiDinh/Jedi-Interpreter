package value

class Notification(val message: String) extends Value
{
  override def toString = message
}

object Notification 
{
  def apply(message2: String) = new Notification(message2)
  val DONE = Notification("DONE")
  val OK = Notification("OK")
  val UNSPECIFIED = Notification("UNSPECIFIED")
}