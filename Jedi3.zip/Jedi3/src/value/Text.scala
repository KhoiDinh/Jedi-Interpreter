package value
import expression._

//for jedi 2.1
class Text(val body: Expression) extends Value 
