package value
import context._
import expression._

class Thunk(defEnv: Environment, body: Expression) extends Closure(defEnv, body, Nil) {
  var cache: Value = null
  def apply() = {

    if (cache == null) {
      cache = super.apply(Nil,null) //was only null
    }
    cache
  }

}